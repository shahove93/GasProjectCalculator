"""Tiny helper to talk to the MD-02 launcher eval bridge (temp automation)."""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

CMD = Path(
    os.environ.get(
        "MD02_BRIDGE",
        r"C:\Users\user\AppData\Local\Temp\opencode\vp-01-native\bridge.json",
    )
)
RES = CMD.with_name(CMD.name + ".result.json")


def send(script: str, timeout: float = 15.0):
    cmd_id = int(time.time() * 1000)
    payload = {"id": cmd_id, "script": script}
    CMD.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            data = json.loads(RES.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            time.sleep(0.05)
            continue
        if data.get("id") == cmd_id:
            return data
        time.sleep(0.05)
    raise TimeoutError("no eval-bridge result")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit("usage: bridge.py <script.js|script> [timeout]")
    arg = sys.argv[1]
    path = Path(arg)
    script = path.read_text(encoding="utf-8") if path.is_file() else arg
    timeout = float(sys.argv[2]) if len(sys.argv) > 2 else 15.0
    out = send(script, timeout=timeout)
    print(json.dumps(out, ensure_ascii=False, indent=2))

