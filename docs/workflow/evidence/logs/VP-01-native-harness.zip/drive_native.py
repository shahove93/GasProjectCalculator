"""MD-02 native evidence driver (temp automation).

Drives the real pywebview window through the launcher eval bridge and captures
native PrintWindow screenshots at 800x540 and the 760x520 minimum for all
three modes, plus SAKZ/PK, 422 and network checks.
"""
from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path

TMP = Path(r"C:\Users\user\AppData\Local\Temp\opencode\vp-01-native")
ROOT = Path(r"D:\Antigravity\GasProjectCalculator")
SHOTS = ROOT / "docs" / "screenshots"
WINPS = TMP / "window.ps1"

sys.path.insert(0, str(TMP))
import bridge  # noqa: E402

PID = int(sys.argv[1])
PORT = int(sys.argv[2])
OUT = Path(sys.argv[3]) if len(sys.argv) > 3 else TMP / "VP-01-native.json"
EXPECTED = {
    "gsn": ("gsnTotal", "68 250"),
    "gsv": ("gsvTotal", "75 600"),
    "combined": ("combinedTotal", "158 550"),
}


def js(name: str) -> str:
    return (TMP / name).read_text(encoding="utf-8")


def eval_js(script: str):
    out = bridge.send(script, timeout=20)
    if not out.get("ok"):
        raise RuntimeError(out)
    result = out["result"]
    if isinstance(result, str):
        try:
            return json.loads(result)
        except ValueError:
            return result
    return result


def shot(name: str, resize: tuple[int, int] | None = None) -> dict:
    out = SHOTS / name
    cmd = [
        "pwsh", "-NoProfile", "-File", str(WINPS),
        "-ProcessId", str(PID), "-OutFile", str(out),
    ]
    if resize:
        cmd += ["-ResizeW", str(resize[0]), "-ResizeH", str(resize[1])]
    proc = subprocess.run(
        cmd, capture_output=True, text=True, encoding="utf-8", errors="replace"
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr)
    line = proc.stdout.strip().splitlines()[-1]
    info = json.loads(line)
    info["file"] = out.name
    print(
        f"WINDOW {name}: outer={info['outer']} client={info['client']} dpi={info['dpi']}",
        flush=True,
    )
    return info


def wait_total(mode: str) -> dict:
    total_key, expected = EXPECTED[mode]
    deadline = time.time() + 15
    last = None
    while time.time() < deadline:
        data = eval_js(js("js_read.js"))
        last = data
        total = (data.get(total_key) or "").replace("\u00a0", " ")
        if expected in total and not data.get("submitDisabled"):
            return data
        time.sleep(0.15)
    raise RuntimeError(f"total {expected} not reached for {mode}: {last}")


def run_modes(prefix: str, label: str, log: dict) -> None:
    for mode in ("gsn", "gsv", "combined"):
        set_data = eval_js(js(f"js_set_{mode}.js"))
        before_metrics = eval_js(js("js_metrics.js"))
        before_shot = shot(f"visual-01-native-{prefix}-{mode}-before.png")
        eval_js(js("js_submit.js"))
        values = wait_total(mode)
        after_metrics = eval_js(js("js_metrics.js"))
        after_shot = shot(f"visual-01-native-{prefix}-{mode}.png")
        log[label][mode] = {
            "set": set_data,
            "beforeMetrics": before_metrics,
            "beforeScreenshot": before_shot,
            "values": values,
            "afterMetrics": after_metrics,
            "afterScreenshot": after_shot,
        }
        print(
            f"[{label}/{mode}] total={values.get(EXPECTED[mode][0])} "
            f"scroll={after_metrics.get('scroll')} "
            f"hScroll={after_metrics.get('hScroll')} vScroll={after_metrics.get('vScroll')} "
            f"submitInViewport={after_metrics.get('submitInViewport')} "
            f"totalInViewport={after_metrics.get('totalInViewport')} "
            f"tableFits={after_metrics.get('tableFits')}",
            flush=True,
        )


def main() -> int:
    log = {"pid": PID, "port": PORT, "target": {}, "min": {}, "misc": {}}

    log["misc"]["targetWindow"] = shot("visual-01-native-target-window.png")
    run_modes("target", "target", log)

    log["misc"]["sakzPanel"] = eval_js(js("js_sakz.js"))
    eval_js(js("js_422.js"))
    time.sleep(1.2)
    log["misc"]["validation422"] = eval_js(js("js_read.js"))
    log["misc"]["validation422Screenshot"] = shot("visual-01-native-422.png")
    log["misc"]["network"] = eval_js(js("js_network.js"))

    log["misc"]["minWindow"] = shot("visual-01-native-min-window.png", resize=(760, 520))
    log["misc"]["minInitialMetrics"] = eval_js(js("js_metrics.js"))
    run_modes("min", "min", log)

    OUT.write_text(json.dumps(log, ensure_ascii=False, indent=2), encoding="utf-8")
    print("WROTE", OUT, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())

