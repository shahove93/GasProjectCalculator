(() => {
  document.querySelector('[data-mode="gsv"]').click();
  document.getElementById("gsv-sakz").value = "0";
  document.getElementById("gsv-panel").checked = true;
  document.getElementById("calculate-form").requestSubmit();
  return "submitted-invalid-panel";
})()
