(() => {
  const q = (id) => document.getElementById(id);
  const rect = (id) => {
    const e = q(id);
    if (!e) return null;
    const r = e.getBoundingClientRect();
    return {
      left: Math.round(r.left * 10) / 10,
      top: Math.round(r.top * 10) / 10,
      right: Math.round(r.right * 10) / 10,
      bottom: Math.round(r.bottom * 10) / 10,
      width: Math.round(r.width * 10) / 10,
      height: Math.round(r.height * 10) / 10
    };
  };
  const de = document.documentElement;
  const body = document.body;
  const activeIds = ["result-gsn", "result-gsv", "result-combined"];
  let active = null;
  for (const id of activeIds) {
    const e = q(id);
    if (e && getComputedStyle(e).display !== "none") active = id;
  }
  const totalId = { "result-gsn": "total", "result-gsv": "gsv-total", "result-combined": "combined-total" }[active] || null;
  const btn = q("submit-btn");
  const br = btn.getBoundingClientRect();
  const tr = totalId ? q(totalId).getBoundingClientRect() : null;
  const breakdown = active === "result-gsv" ? q("gsv-pipe-breakdown") : (active === "result-combined" ? q("combined-gsv-pipe-breakdown") : null);
  return JSON.stringify({
    inner: [innerWidth, innerHeight],
    devicePixelRatio: window.devicePixelRatio,
    scroll: [window.scrollX, window.scrollY],
    docScroll: [de.scrollWidth, de.scrollHeight],
    docClient: [de.clientWidth, de.clientHeight],
    bodyScroll: [body.scrollWidth, body.scrollHeight],
    bodyClient: [body.clientWidth, body.clientHeight],
    bodyOverflowX: getComputedStyle(body).overflowX,
    bodyOverflowY: getComputedStyle(body).overflowY,
    hScroll: de.scrollWidth > de.clientWidth,
    vScroll: de.scrollHeight > de.clientHeight,
    activeResult: active,
    totalId: totalId,
    submitRect: rect("submit-btn"),
    totalRect: totalId ? rect(totalId) : null,
    submitInViewport: br.top >= 0 && br.left >= 0 && br.bottom <= innerHeight && br.right <= innerWidth,
    totalInViewport: tr ? tr.top >= 0 && tr.left >= 0 && tr.bottom <= innerHeight && tr.right <= innerWidth : false,
    tableFits: breakdown ? breakdown.scrollWidth <= breakdown.clientWidth + 1 : null,
    fontSizes: {
      body: getComputedStyle(body).fontSize,
      label: getComputedStyle(document.querySelector(".field .label")).fontSize,
      input: getComputedStyle(q("length")).fontSize,
      total: getComputedStyle(q("total")).fontSize,
      sectionLabel: getComputedStyle(document.querySelector(".section-label")).fontSize,
      button: getComputedStyle(btn).fontSize
    },
    formScroll: (() => {
      const fs = q("group-gsn").closest(".form-scroll");
      return { client: fs.clientHeight, scroll: fs.scrollHeight };
    })(),
    resultDetail: (() => {
      const d = active ? document.querySelector("#" + active + " .result-detail") : null;
      return d ? { client: d.clientHeight, scroll: d.scrollHeight } : null;
    })()
  });
})()
