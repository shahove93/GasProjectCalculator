(() => {
  const resources = performance.getEntriesByType("resource").map((entry) => entry.name);
  return JSON.stringify({
    resources,
    external: resources.filter((name) => /^https?:\/\//.test(name)),
    styleSheetImports: Array.from(document.styleSheets).filter((sheet) => {
      try { return sheet.href && /^https?:\/\//.test(sheet.href); } catch (e) { return false; }
    }).length
  });
})()
