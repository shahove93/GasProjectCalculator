(() => {
  const q = (id) => document.getElementById(id);
  const text = (id) => (q(id) ? q(id).textContent : null);
  const de = document.documentElement;
  const active = ["result-gsn", "result-gsv", "result-combined"].find(
    (id) => getComputedStyle(q(id)).display !== "none"
  ) || null;
  return JSON.stringify({
    active,
    title: text("result-title"),
    gsnTotal: text("total"),
    gsvTotal: text("gsv-total"),
    combinedTotal: text("combined-total"),
    gsvMetrage: text("gsv-total_length"),
    combinedGsvMetrage: text("combined-gsv-total_length"),
    gsvBreakdown: {
      up_to_25: [text("gsv-pipe-up_to_25-length"), text("gsv-pipe-up_to_25-included"), text("gsv-pipe-up_to_25-billable"), text("gsv-pipe-up_to_25-rate"), text("gsv-pipe-up_to_25-surcharge")],
      from_32_to_40: [text("gsv-pipe-from_32_to_40-length"), text("gsv-pipe-from_32_to_40-included"), text("gsv-pipe-from_32_to_40-billable"), text("gsv-pipe-from_32_to_40-rate"), text("gsv-pipe-from_32_to_40-surcharge")],
      diameter_57: [text("gsv-pipe-diameter_57-length"), text("gsv-pipe-diameter_57-included"), text("gsv-pipe-diameter_57-billable"), text("gsv-pipe-diameter_57-rate"), text("gsv-pipe-diameter_57-surcharge")]
    },
    combinedGsvBreakdown: {
      up_to_25: [text("combined-gsv-pipe-up_to_25-length"), text("combined-gsv-pipe-up_to_25-included"), text("combined-gsv-pipe-up_to_25-billable"), text("combined-gsv-pipe-up_to_25-rate"), text("combined-gsv-pipe-up_to_25-surcharge")],
      from_32_to_40: [text("combined-gsv-pipe-from_32_to_40-length"), text("combined-gsv-pipe-from_32_to_40-included"), text("combined-gsv-pipe-from_32_to_40-billable"), text("combined-gsv-pipe-from_32_to_40-rate"), text("combined-gsv-pipe-from_32_to_40-surcharge")],
      diameter_57: [text("combined-gsv-pipe-diameter_57-length"), text("combined-gsv-pipe-diameter_57-included"), text("combined-gsv-pipe-diameter_57-billable"), text("combined-gsv-pipe-diameter_57-rate"), text("combined-gsv-pipe-diameter_57-surcharge")]
    },
    errorVisible: getComputedStyle(q("error")).display !== "none",
    errorText: text("error"),
    submitDisabled: q("submit-btn").disabled,
    scroll: [scrollX, scrollY],
    doc: [de.scrollWidth, de.scrollHeight],
    client: [de.clientWidth, de.clientHeight],
    hScroll: de.scrollWidth > de.clientWidth,
    vScroll: de.scrollHeight > de.clientHeight
  });
})()
