(() => {
  const q = (id) => document.getElementById(id);
  const state = () => ({ sakz: q("gsv-sakz").value, disabled: q("gsv-panel").disabled, checked: q("gsv-panel").checked });
  q("gsv-sakz").value = "0";
  q("gsv-sakz").dispatchEvent(new Event("input", { bubbles: true }));
  const zero = state();
  q("gsv-sakz").value = "1";
  q("gsv-sakz").dispatchEvent(new Event("input", { bubbles: true }));
  const one = state();
  q("gsv-panel").checked = true;
  q("gsv-sakz").value = "0";
  q("gsv-sakz").dispatchEvent(new Event("input", { bubbles: true }));
  const reset = state();
  return JSON.stringify({ zero, one, reset });
})()
