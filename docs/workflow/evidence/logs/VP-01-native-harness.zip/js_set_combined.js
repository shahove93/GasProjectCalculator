(() => {
  document.querySelector('[data-mode="combined"]').click();
  const set = (id, value) => { document.getElementById(id).value = String(value); };
  const check = (id, value) => { document.getElementById(id).checked = value; };
  set("length", 10);
  set("angles", 0);
  set("excavator_hours", 0);
  check("hdd", false);
  check("hydraulic_hammer", false);
  check("has_grpsh", false);
  set("gsv-length-up-to-25", 4);
  set("gsv-length-32-40", 0);
  set("gsv-length-57", 4);
  set("gsv-holes", 0);
  set("gsv-sakz", 0);
  check("gsv-panel", false);
  check("is_district", true);
  return JSON.stringify({ mode: "combined", gsn: 10, gsv: [4, 0, 4], district: true });
})()
