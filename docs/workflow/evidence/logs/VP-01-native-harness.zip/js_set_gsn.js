(() => {
  document.querySelector('[data-mode="gsn"]').click();
  const set = (id, value) => { document.getElementById(id).value = String(value); };
  const check = (id, value) => { document.getElementById(id).checked = value; };
  set("length", 10);
  set("angles", 0);
  set("excavator_hours", 0);
  check("hdd", false);
  check("hydraulic_hammer", false);
  check("has_grpsh", false);
  check("is_district", false);
  return JSON.stringify({ mode: "gsn", length: 10, district: false });
})()
