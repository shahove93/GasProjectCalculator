(() => {
  document.querySelector('[data-mode="gsv"]').click();
  const set = (id, value) => { document.getElementById(id).value = String(value); };
  const check = (id, value) => { document.getElementById(id).checked = value; };
  set("gsv-length-up-to-25", 4);
  set("gsv-length-32-40", 0);
  set("gsv-length-57", 4);
  set("gsv-holes", 0);
  set("gsv-sakz", 0);
  check("gsv-panel", false);
  check("is_district", false);
  return JSON.stringify({ mode: "gsv", lengths: [4, 0, 4], district: false });
})()
