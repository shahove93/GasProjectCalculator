document.getElementById("submit-btn").click();
"submitted";
