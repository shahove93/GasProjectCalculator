param(
    [Parameter(Mandatory=$true)][int]$ProcessId,
    [string]$OutFile = "",
    [string]$Filter = "СС.Расчет",
    [int]$ResizeW = 0,
    [int]$ResizeH = 0
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Drawing

Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public class Rd06Win {
  public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lParam);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern int GetWindowTextLength(IntPtr hWnd);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);
  [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr hWnd, out RECT rect);
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int x, int y, int cx, int cy, uint flags);
  [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr hWnd, IntPtr hdc, uint flags);
  [DllImport("user32.dll")] public static extern uint GetDpiForWindow(IntPtr hWnd);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
}
"@

$windows = New-Object System.Collections.ArrayList
$callback = {
    param($hWnd, $lParam)
    $procId = 0
    [Rd06Win]::GetWindowThreadProcessId($hWnd, [ref]$procId) | Out-Null
    if ($procId -eq [uint32]$ProcessId) {
        $len = [Rd06Win]::GetWindowTextLength($hWnd)
        $sb = New-Object System.Text.StringBuilder ($len + 1)
        [Rd06Win]::GetWindowText($hWnd, $sb, $sb.Capacity) | Out-Null
        if ([Rd06Win]::IsWindowVisible($hWnd) -and $sb.ToString() -like "*$Filter*") {
            $rect = New-Object Rd06Win+RECT
            [Rd06Win]::GetWindowRect($hWnd, [ref]$rect) | Out-Null
            $crect = New-Object Rd06Win+RECT
            [Rd06Win]::GetClientRect($hWnd, [ref]$crect) | Out-Null
            $null = $windows.Add([pscustomobject]@{
                Handle = $hWnd.ToInt64()
                Title = $sb.ToString()
                Left = $rect.Left; Top = $rect.Top; Right = $rect.Right; Bottom = $rect.Bottom
                Width = $rect.Right - $rect.Left; Height = $rect.Bottom - $rect.Top
                ClientWidth = $crect.Right - $crect.Left; ClientHeight = $crect.Bottom - $crect.Top
            })
        }
    }
    return $true
}
[Rd06Win]::EnumWindows($callback, [IntPtr]::Zero) | Out-Null

if ($windows.Count -eq 0) { Write-Error "No matching window for pid $ProcessId"; exit 2 }
$target = $windows[0]

if ($ResizeW -gt 0 -and $ResizeH -gt 0) {
    [Rd06Win]::SetWindowPos([IntPtr]$target.Handle, [IntPtr]::Zero, 0, 0, $ResizeW, $ResizeH, 0x0002 -bor 0x0004 -bor 0x0010) | Out-Null
    Start-Sleep -Milliseconds 800
    $r = New-Object Rd06Win+RECT
    [Rd06Win]::GetWindowRect([IntPtr]$target.Handle, [ref]$r) | Out-Null
    $cr = New-Object Rd06Win+RECT
    [Rd06Win]::GetClientRect([IntPtr]$target.Handle, [ref]$cr) | Out-Null
    $target.Left = $r.Left; $target.Top = $r.Top
    $target.Width = $r.Right - $r.Left; $target.Height = $r.Bottom - $r.Top
    $target.ClientWidth = $cr.Right - $cr.Left; $target.ClientHeight = $cr.Bottom - $cr.Top
}

$dpi = 0
try { $dpi = [Rd06Win]::GetDpiForWindow([IntPtr]$target.Handle) } catch { $dpi = 0 }

if ($OutFile -ne "") {
    $bmp = New-Object System.Drawing.Bitmap $target.Width, $target.Height
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $hdc = $g.GetHdc()
    $ok = [Rd06Win]::PrintWindow([IntPtr]$target.Handle, $hdc, 2)  # PW_RENDERFULLCONTENT
    $g.ReleaseHdc($hdc)
    $dir = Split-Path -Parent $OutFile
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
    $bmp.Save($OutFile, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose(); $bmp.Dispose()
}

[pscustomobject]@{
    pid = $ProcessId
    handle = $target.Handle
    title = $target.Title
    outer = @($target.Width, $target.Height)
    client = @($target.ClientWidth, $target.ClientHeight)
    dpi = $dpi
    screenshot = $OutFile
} | ConvertTo-Json -Compress
